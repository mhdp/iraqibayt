class SortBy {
  int id;
  String name;

  SortBy({this.id, this.name});
}
