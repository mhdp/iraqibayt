class Depart {
  final int id;
  final String name;
  final String image;
  final String url;

  const Depart({this.id, this.name, this.image, this.url});
}
