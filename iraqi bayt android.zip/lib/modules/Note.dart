class Note {
  final int id;
  final String content;

  const Note({this.id, this.content});
}
