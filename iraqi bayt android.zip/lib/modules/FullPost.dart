class FullPost {
  int id;
  String title;
  String description;
  int categoryId;
  int subCategoryId;
  int cityId;
  int regionId;
  int currencyId;
  int unitId;
  int price;
  int area;
  int bathroomNum;
  int bedroomNum;
  int carNum;
  int floorNum;
  String phone;
  String paymentMethod;
}
