class ICurrency {
  int id;
  String shortName;
  double forOneDollar;

  ICurrency({this.id, this.shortName, this.forOneDollar});
}
